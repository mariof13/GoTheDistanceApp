
package org.academicode.tipcalculator;

/**
 * Created by namirfawaz on 12/8/15.
 */
        import android.content.Context;
        import android.content.SharedPreferences;
        import android.content.SharedPreferences.Editor;
        import android.preference.PreferenceManager;
        import android.app.Activity;

public class
        SharedPreference extends Activity{

    public static final String UNIT = "unit";
    public static final String KEY = "key";
    public static final String UNIT2 = "unit2";
    public static final String KEY2 = "key2";
    public static final String NAME = "name";
    public static final String NAME_KEY = "name_key";
    public static final String EMAIL = "email";
    public static final String EMAIL_KEY = "email_key";
    public static final String ID = "id";
    public static final String ID_KEY = "id_key";
}
