package org.academicode.tipcalculator;

import android.app.Activity;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import static android.location.LocationManager.GPS_PROVIDER;


public class MyLocationListener extends Activity implements LocationListener {

	public void OnCreate() {

		LocationListener locationListener = new MyLocationListener();
		LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		Location location = lm.getLastKnownLocation(GPS_PROVIDER);

		double Longitude = location.getLongitude();
		double Latitude = location.getLatitude();

		lm.requestLocationUpdates(GPS_PROVIDER, 1000, 0, locationListener);
	}

	@Override
	public void onLocationChanged(Location location) {

		}
		// called when the listener is notified with a location update from the GPS


	@Override
	public void onProviderDisabled(String provider) {
		// called when the GPS provider is turned off (user turning off the GPS on the phone)
	}

	@Override
	public void onProviderEnabled(String provider) {
		// called when the GPS provider is turned on (user turning on the GPS on the phone)
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
		// called when the status of the GPS provider changes
	}
}

