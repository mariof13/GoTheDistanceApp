/*****************************************************************************************
 * Adapted and tortured by Julian Trinh and Connor Richmond for use in ENG EC 327
 * Source code from https://github.com/academicode/app-simple-tip-calculator/tree/session-7
 * Sweet tutorial at https://www.youtube.com/watch?v=Z3jzIYkxB1s (where the source is from)
 * Boston University: College of Engineering
 * Spring 2015
 *****************************************************************************************/
package org.academicode.tipcalculator;
//This is the class that will first be run when the app is first opened

//import is #include from C++
import android.app.Activity;
import android.location.LocationListener;
import android.os.Handler;
import android.support.v4.app.ActionBarDrawerToggle;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Chronometer;

import android.location.Location;
import android.location.LocationManager;

import org.w3c.dom.Text;

import static android.location.LocationManager.GPS_PROVIDER;
//import android.widget.ImageView;
//import android.view.View;



//-----------------------------------------------------------------------------------------------------------------
/*
import android.location.Location;
import android.location.LocationManager;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;
*/
//-----------------------------------------------------------------------------------------------------------------

//Extends = inherits, implements means it interfaces with another class
public class Main extends SharedPreference implements OnClickListener {
//	//Declaring and setting string variables
//	private static final String TAG_DEBUG = Main.class.getName();
//	public static final String TAG_TIP = "tag";
//	public static final String TAG_GRAND_TOTAL = "total";

    //Creating the EditText object
    private EditText et;

    //Creating button objects, which extend (inherit) the View class

    //private Button startbutton;
    private Button stopbutton;
    private Button unitsbutton;
    private Button registration;
    private ImageButton imstartb;
    private ImageButton imstopb;
//    private Location newDestination;
//    private boolean started;
    private ProgressBar pb;
    private int progressStatus = 0;
    private TextView MariotextView;
    private Handler handler2 = new Handler();

    //-----------------------------------------------------------------------------------------------------------------

    private TextView accReadout;
    //	private TextView latReadout;
//	private TextView lonReadout;
    private TextView dist;
    private TextView speed;
    private ProgressDialog progress;
//-----------------------------------------------------------------------------------------------------------------


    //For saving funtion----------------------------------------------
    private SharedPreference sharedPreference;

    Activity context = this;


    Handler handler = new Handler();

    @Override
	/*An onCreate method/function is what is called when a screen is first showed.
	  In this case, this is the main menu screen.
	*/
    protected void onCreate(Bundle savedInstanceState) {
        //The super keyword is used to refer to the parent class in java
        super.onCreate(savedInstanceState);
        progress = new ProgressDialog(this); //<---------------Mario, uncomment this to make the progress bar work a gain
        //int progress = 0;

		/*Set the texts views so they display according to the parameters in result.xml*/
//		distTextView = (TextView) findViewById(R.id.);
//		speedTextView = (TextView) findViewById(R.id.total);


        //How the activity actually looks is inside main.xml, inside the layout folder
        setContentView(R.layout.main);

        // The edit text has a string value set by the editText1 ID in Main.xml
        et = (EditText) findViewById(R.id.editText1);

        //The buttons have parameters corresponding to the IDs in Main.xml

        //startbutton = (Button) findViewById(R.id.start);
        //stopbutton = (Button) findViewById(R.id.stop);
        unitsbutton = (Button) findViewById(R.id.units);
        imstartb = (ImageButton) findViewById(R.id.imstart);
        imstopb = (ImageButton) findViewById(R.id.imstop);
        pb = (ProgressBar) findViewById(R.id.progressBar2);
        MariotextView = (TextView) findViewById(R.id.mariotextView);
        registration = (Button) findViewById(R.id.startRegistration);
//-----------------------------------------------------------------------------------------------------------------

        accReadout = (TextView) findViewById(R.id.accuracyReadout);
        //latReadout = (TextView) findViewById(R.id.latitudeReadout);
        //lonReadout = (TextView) findViewById(R.id.longitudeReadout);
        dist = (TextView) findViewById(R.id.distance);
        speed = (TextView) findViewById(R.id.speedReadout);

//-----------------------------------------------------------------------------------------------------------------


        SharedPreferences settings;
        settings = context.getSharedPreferences(UNIT, Context.MODE_PRIVATE);
        int bar1 = settings.getInt(KEY, 0);


		/*The buttons now have onClickListeners set, a method/function of the button class
		 * to start a new activity/intent when pressed. In this case, pressing a button
		 * will go to the results page.
		 * */

        //startbutton.setOnClickListener(this);
        //stopbutton.setOnClickListener(this);
        unitsbutton.setOnClickListener(this);
        imstartb.setOnClickListener(this);
        imstopb.setOnClickListener(this);
        pb.setOnClickListener(this);
        registration.setOnClickListener(this);

        SharedPreferences settings3;
        settings3 = context.getSharedPreferences(NAME, Context.MODE_PRIVATE);


        //checks save file to determine if a name if saved, if not, a sign up or register file is called
        if (settings3.getString(NAME_KEY, null) == null) {

            Intent signupActivity = new Intent(Main.this, signup.class);
            //Intent startIntent = new Intent(Main.this, Result.class); //Pass this the activity you are currently in and the activity CLASS you want to go to
            startActivity(signupActivity);
        }

        /*boolean i = true;
        if (i)
        {
            Intent signupActivity = new Intent(Main.this, signup.class);
            //Intent startIntent = new Intent(Main.this, Result.class); //Pass this the activity you are currently in and the activity CLASS you want to go to
            startActivity(signupActivity);
        }
        else
        {
*/


//		imstartb.setOnClickListener(new View.OnClickListener() {
//			@Override
//			public void onClick(View v) {
//				Toast.makeText(getApplicationContext(),"You download is resumed",Toast.LENGTH_LONG).show();
//			}
//		});

    }
//-------------------Mario Stuff--------------------------------------//

    //  pb.setVisibility(view.INVISIBLE);


    //end of mario stuff---------------------------------------------------//
    @Override
	/*onClick is what is called when the buttons are pressed and they take in Views as arguments
	 * as buttons are children of the view class, buttons can polymorphically be passed in. The button
	 * that called the onClick is automatically fed in*/
    public void onClick(View v) {

        SharedPreferences settings;
        settings = context.getSharedPreferences(UNIT, Context.MODE_PRIVATE);
        int bar1 = settings.getInt(KEY, 0);

        //The switch statements grab the id values of the button pressed and calculates the tip accordingly
        switch (v.getId()) {

            case R.id.units: {

                Intent unitsActivity = new Intent(Main.this, Result.class);
                //Intent startIntent = new Intent(Main.this, Result.class); //Pass this the activity you are currently in and the activity CLASS you want to go to
                startActivity(unitsActivity);

                //launchUnitActivity(disttest, speedtest);

                break;
            }
            case R.id.startRegistration: {
                Intent regActivity = new Intent(Main.this, registration.class);
                //Intent startIntent = new Intent(Main.this, Result.class); //Pass this the activity you are currently in and the activity CLASS you want to go to
                startActivity(regActivity);
                //launchUnitActivity(disttest, speedtest);
                break;
            }
            case R.id.imstart: {
                //Pulls the input from the EditText
                String text = et.getText().toString();

                //If the user tried to proceed without entering a value
                if (text.equals("")) {
                    //Show a toast telling them they need to enter a value. Text is pulled from strings.xml
                    Toast.makeText(Main.this, getResources().getString(R.string.error_et), Toast.LENGTH_LONG).show();
                    //Breaks out of the onClick, as we do not want to launch a new Activity without entered values
                    return;
                }

                //if user tries to proceed and distance is less than 0.5 miles
                else if ((Double.parseDouble(et.getText().toString())) < 0.5 && bar1 == 0) {
                    //Show a toast telling them they need to enter a value. Text is pulled from strings.xml
                    Toast.makeText(Main.this, getResources().getString(R.string.error_lessmi), Toast.LENGTH_LONG).show();
                    //Breaks out of the onClick, as we do not want to launch a new Activity without entered values
                    return;
                } else if ((Double.parseDouble(et.getText().toString())) < 0.5 && bar1 == 1) {
                    //Show a toast telling them they need to enter a value. Text is pulled from strings.xml
                    Toast.makeText(Main.this, getResources().getString(R.string.error_lesskm), Toast.LENGTH_LONG).show();
                    //Breaks out of the onClick, as we do not want to launch a new Activity without entered values
                    return;
                } else {
                    Chronometer MyChron;
                    MyChron = (Chronometer) findViewById(R.id.timer);
                    ((Chronometer) findViewById(R.id.timer)).setBase(SystemClock.elapsedRealtime());
                    ((Chronometer) findViewById(R.id.timer)).start();

//                    LocationListener locationListener = new MyLocationListener();
//
//                    LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
//
//                    Location myLoc = lm.getLastKnownLocation(GPS_PROVIDER);
//
////
//
////                                        if(!started) { started = true;
////newDestination = lm.getLastKnownLocation(GPS_PROVIDER);
////
////                    }
//                    Location destination = lm.getLastKnownLocation(GPS_PROVIDER);
//
//                    lm.requestLocationUpdates(GPS_PROVIDER, 1000, 0, locationListener);

                    //process(v);
                    final int progHelp = (int) Math.round((Double.parseDouble(et.getText().toString())));
                    //pb.setMinimumHeight(100);
                    progressStatus = 0;
                    pb.setMax(progHelp);
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            while (progressStatus < progHelp) {
                                progressStatus += 1;//<--------------------------
                                handler2.post(new Runnable() {
                                    //@Override
                                    public void run() {
                                        pb.setProgress(progressStatus);
                                        MariotextView.setText("Progress: " + progressStatus + "/" + progHelp);//progress.getMax());
                                    }
                                });
                                try {
                                    Thread.sleep(1000);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }).start();


                    //-----------progress attempt-----------------//
                    //pb.setVisibility(View.VISIBLE);
                    //pb.setProgress(0);
                    // pb.setMax((Integer.parseInt(et.getText().toString())));
                    // pb.setProgressDrawable(v.getResources().getDrawable(R.drawable.progressBar2));


                    //---------end attempt-----------------------------///
                    //public void open(View view){
                    //progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                    // progress.setIndeterminate(true);
                    // progress.show();


                    //   final Thread t = new Thread() {

                    //@Override
                    //       public void run() {

                    //          int increment = 0;
                    //          while (increment < 130) {
                    //              try {
                    //                  increment = increment + 5;
                    //                   sleep(0);
                    // /                  //increment = increment + 5;
                    //                   pb.setProgress(increment);
                    //               } catch (InterruptedException e) {
                    //                   e.printStackTrace();
                    //               }
                    //           }

                    //       }
                    //   };
                    //   t.start();

                    //-----------------------------------------------------------------------------------------------------------------

//					LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
//					Location myLoc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//
//
//					Location destination = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
//					destination.setLatitude(40.712598);
//					destination.setLongitude(-74.005487);
//					//string ii = String.valueOf(myLoc.getLatitude());
//                    accReadout.setText(String.valueOf(myLoc.getAccuracy()));
////					latReadout.setText(String.valueOf(myLoc.getLatitude()));
////					lonReadout.setText(String.valueOf(myLoc.getLongitude()));
//                    speed.setText(String.valueOf(myLoc.getSpeed()));
//                    dist.setText(String.valueOf(myLoc.distanceTo(destination) / 1000) + "kilometers");

//-----------------------------------------------------------------------------------------------------------------
                    break;

                }



            }
            case R.id.imstop: {
                ((Chronometer) findViewById(R.id.timer)).stop();
//                started = false;
                // ((ProgressBar) findViewById(R.id.progressBar2)).stop();
                //((Chronometer) findViewById(R.id.timer)).
                final int progHelp = (int) Math.round((Double.parseDouble(et.getText().toString())));
                pb.setMinimumHeight(100);
                progressStatus = 0;
                final int progstop = 2;
                pb.setMax(progHelp);
                pb.setProgress(progstop);
                MariotextView.setText("Progress: " + progstop + "/" + progress.getMax());


                break;
            }

            default: {
                break;
            }
        }

    }
}