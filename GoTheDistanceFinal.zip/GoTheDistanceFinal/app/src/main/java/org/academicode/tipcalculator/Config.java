package org.academicode.tipcalculator;

public class Config {

    //Address of our scripts of the CRUD
    public static final String URL_ADD="http://default-environment-pcmwtehmzk.elasticbeanstalk.com/addEmp.php";
    public static final String URL_GET_ALL = "http://default-environment-pcmwtehmzk.elasticbeanstalk.com/getAllEmp.php";
    public static final String URL_GET_EMP = "http://default-environment-pcmwtehmzk.elasticbeanstalk.com/getEmp.php?id=";
    public static final String URL_UPDATE_EMP = "http://default-environment-pcmwtehmzk.elasticbeanstalk.com/updateEmp.php";
    public static final String URL_DELETE_EMP = "http://default-environment-pcmwtehmzk.elasticbeanstalk.com/deleteEmp.php?id=";
    //=========================================================================================================================
    public static final String URL_GET_USER = "http://default-environment-pcmwtehmzk.elasticbeanstalk.com/getUser.php?id=";
    public static final String URL_ADD_USER ="http://default-environment-pcmwtehmzk.elasticbeanstalk.com/addUser.php";
    public static final String URL_ADD_RECORD = "http://default-environment-pcmwtehmzk.elasticbeanstalk.com/addRecord.php";
    public static final String URL_GET_LEADERBOARD = "http://default-environment-pcmwtehmzk.elasticbeanstalk.com/getLeaderboard.php?dis=";
    public static final String URL_GET_RECORDS = "http://default-environment-pcmwtehmzk.elasticbeanstalk.com/getPersonalRecords.php?id=";
    public static final String URL_GET_COMP_REC = "http://default-environment-pcmwtehmzk.elasticbeanstalk.com/getCompRecord.php?id=";
    public static final String URL_SEND_EMAIL = "http://default-environment-pcmwtehmzk.elasticbeanstalk.com/email.php";

    //Keys that will be used to send the request to php scripts
    public static final String KEY_EMP_ID = "id";
    public static final String KEY_EMP_NAME = "name";
    public static final String KEY_EMP_DESG = "desg";
    public static final String KEY_EMP_SAL = "salary";
    //==================================================
    public static final String KEY_USR_EMAIL = "email";
    public static final String KEY_USR_NAME = "name";
    public static final String KEY_USR_ID = "userid";
    public static final String KEY_USR_UNITS = "units";
    public static final String KEY_USR_DIS = "dis";
    public static final String KEY_USR_TIME = "time";
    public static final String KEY_USR_AVGSP = "avgsp";
    public static final String KEY_USR_MAXSP = "maxsp";

    //JSON Tags
    public static final String TAG_JSON_ARRAY="result";
    public static final String TAG_ID = "id";
    public static final String TAG_NAME = "name";
    public static final String TAG_DESG = "desg";
    public static final String TAG_SAL = "salary";
    //=================================================
    public static final String TAG_EMAIL = "email";
    public static final String TAG_DATE = "date";
    public static final String TAG_DIS = "dis";
    public static final String TAG_UNITS = "units";
    public static final String TAG_TIME = "time";
    public static final String TAG_AVGSP = "avgsp";
    public static final String TAG_EMAILMSG = "message";
    public static final String TAG_EMAILADDRESS = "to";
    public static final String TAG_EMAILSUBJECT = "subject";


    //employee id to pass with intent
    public static final String EMP_ID = "emp_id";

}
