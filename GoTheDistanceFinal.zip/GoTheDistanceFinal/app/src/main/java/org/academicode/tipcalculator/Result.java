/*****************************************************************************************
 * Adapted and tortured by Julian Trinh and Connor Richmond for use in ENG EC 327
 * Source code from https://github.com/academicode/app-simple-tip-calculator/tree/session-7
 * Sweet tutorial at https://www.youtube.com/watch?v=Z3jzIYkxB1s (where the source is from)
 * Boston University: College of Engineering
 * Spring 2015
 *****************************************************************************************/
package org.academicode.tipcalculator;
/*
 * This is the results page that is displayed after you the onClick is called from Main.java
 * */

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

public class Result extends SharedPreference
{
	//Initializes TextViews to display total and tip
	private TextView distTextView;
	private TextView speedTextView;

	//For saving funtion
	private SharedPreference sharedPreference;

	Activity context = this;

	//Initializes a button
	private Button finished;


	//initialize seekbar
	private SeekBar bardist;
	private SeekBar barspeed;

	//default distance and default speed

	
	@Override
	//When this activity is called, onCreate is called
	protected void onCreate(Bundle savedInstanceState) 
	{




		super.onCreate(savedInstanceState);
		
		//How this activity actually looks is set inside result.xml
		setContentView(R.layout.result);

		sharedPreference = new SharedPreference();

		//Initializes button to the parameters in result.xml
		finished = (Button) findViewById(R.id.confirm);
		


		//initializes seek bar
		bardist = (SeekBar) findViewById(R.id.seekBarDist);
		barspeed = (SeekBar) findViewById(R.id.seekBarSpeed);

		SharedPreferences settings;
		settings = context.getSharedPreferences(UNIT, Context.MODE_PRIVATE);
		int bar1 = settings.getInt(KEY, 0);//if no saved value exists, set to 0

		String strdist;

		if (bar1 == 0) {
			strdist = "miles";
			distTextView = (TextView) findViewById(R.id.distView);
			distTextView.setText("Unit of distance is now set to: " + strdist);
		}
		else {
			bardist.setProgress(bar1);
			strdist = "kilometers";
			distTextView = (TextView) findViewById(R.id.distView);
			distTextView.setText("Unit of distance is now set to: " + strdist);
		}

		//Initializing barspeed value

		SharedPreferences settings2;//---------------------------------------------------------------------------------------------------------------retrieve save
 		settings2 = context.getSharedPreferences(UNIT2, Context.MODE_PRIVATE);
		int bar2 = settings2.getInt(KEY2, 0);

		String strspeed;

		if (bar2 == 0) {
			strspeed = "miles per hour";
			speedTextView = (TextView) findViewById(R.id.speedView);
			speedTextView.setText("Unit of distance is now set to: " + strspeed);
		}
		else {
			barspeed.setProgress(bar2);
			strspeed = "kilometers per hour";
			speedTextView = (TextView) findViewById(R.id.speedView);
			speedTextView.setText("Unit of distance is now set to: " + strspeed);
		}



		//seekbar listener for distance
		bardist.setOnSeekBarChangeListener(
				new SeekBar.OnSeekBarChangeListener() {
					int progressval;
					String strdist;

					@Override
					public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
						progressval = progress;

						if (bardist.getProgress() == 0) {
							strdist = "miles";
							distTextView.setText("Unit of distance is now set to: " + strdist);

						} else {
							strdist = "kilometers";
							distTextView.setText("Unit of distance is now set to: " + strdist);

						}
					}

					@Override
					public void onStartTrackingTouch(SeekBar seekBar) {
						if (bardist.getProgress() == 0) {
							strdist = "miles";
							distTextView.setText("Unit of distance is now set to: " + strdist);

						} else {
							strdist = "kilometers";
							distTextView.setText("Unit of distance is now set to: " + strdist);

						}
					}

					@Override
					public void onStopTrackingTouch(SeekBar seekBar) {
						if (bardist.getProgress() == 0) {
							strdist = "miles";
							distTextView.setText("Unit of distance is now set to: " + strdist);

						} else {
							strdist = "kilometers";
							distTextView.setText("Unit of distance is now set to: " + strdist);

						}

					}
				}

		);


		//seekbar listener for speed
		barspeed.setOnSeekBarChangeListener(
				new SeekBar.OnSeekBarChangeListener() {
					int progressval;
					String strspeed;

					@Override
					public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
						progressval = progress;

						if (barspeed.getProgress() == 0) {
							strspeed = "miles per hour";
							speedTextView.setText("Unit of distance is now set to: " + strspeed);

						} else {
							strspeed = "kilometers per hour";
							speedTextView.setText("Unit of distance is now set to: " + strspeed);

						}
					}

					@Override
					public void onStartTrackingTouch(SeekBar seekBar) {
						if (barspeed.getProgress() == 0) {
							strspeed = "miles per hour";
							speedTextView.setText("Unit of distance is now set to: " + strspeed);

						} else {
							strspeed = "kilometers per hour";
							speedTextView.setText("Unit of distance is now set to: " + strspeed);

						}
					}

					@Override
					public void onStopTrackingTouch(SeekBar seekBar) {
						if (barspeed.getProgress() == 0) {
							strspeed = "miles per hour";
							speedTextView.setText("Unit of distance is now set to: " + strspeed);

						} else {
							strspeed = "kilometers per hour";
							speedTextView.setText("Unit of distance is now set to: " + strspeed);

						}

					}
				}

		);
		


		
		//Sets an onClickListener for the finished button
		finished.setOnClickListener(new OnClickListener() 
		{
			@Override
			//If clicked, call the finish method
			public void onClick(View v) 
			{
				//Save distance progress bar
				Context mContext = getApplicationContext();
				SharedPreferences mPrefs = mContext.getSharedPreferences(UNIT, Context.MODE_PRIVATE);
				SharedPreferences.Editor editor = mPrefs.edit();
				if (bardist.getProgress() == 0){
					editor.putInt(KEY, 0);
					editor.commit();
				}
				else {
					editor.putInt(KEY, 1);
					editor.commit();
				}
				//Save speed progress bar
				Context mContext2 = getApplicationContext();
				SharedPreferences mPrefs2 = mContext2.getSharedPreferences(UNIT2, Context.MODE_PRIVATE);
				SharedPreferences.Editor editor2 = mPrefs2.edit();
				if (barspeed.getProgress() == 0){
					editor2.putInt(KEY2, 0);
					editor2.commit();
				}
				else{
					editor2.putInt(KEY2, 1);
					editor2.commit();
				}

				//Finish ends the current activity and goes back to the activity that called this one (Main in this case)
				finish();
			}
		});
	}
	
//	private void initializeTextViews()
//	{
//		//Sets doubles according to the values "pushed" from Main.java
//		double tdist = getIntent().getExtras().getDouble(Main.TAG_TIP);
//		double tspeed = getIntent().getExtras().getDouble(Main.TAG_GRAND_TOTAL);
//
//		//Sets the strings accordingly
//		String currentTipText = tipTextView.getText().toString();
//
//		currentTipText = currentTipText + tdist;
//
//		String currentTotalText = totalTextView.getText().toString();
//
//		currentTotalText = currentTotalText + tspeed;
//
//		//Sets the texts to display the values
//		tipTextView.setText(currentTipText);
//		totalTextView.setText(currentTotalText);
//	}
}
