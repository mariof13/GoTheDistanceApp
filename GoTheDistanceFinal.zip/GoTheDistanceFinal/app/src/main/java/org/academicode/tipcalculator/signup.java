package org.academicode.tipcalculator;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Created by Ivan on 12/9/2015.
 */
public class signup extends SharedPreference{
/*
    //Initializes a button
    private Button finished2;
    private Button registerButton;
    private Button signInButton;

    @Override
    //When this activity is called, onCreate is called
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);

        //How this activity actually looks is set inside result.xml
        setContentView(R.layout.signup2);

        //Initializes button to the parameters in result.xml
        finished2 = (Button) findViewById(R.id.confirm3);

                //Sets an onClickListener for the finished button
        finished2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            //If clicked, call the finish method
            public void onClick(View v)
            {
                //Finish ends the current activity and goes back to the activity that called this one (Main in this case)
                finish();
            }
        });

    }

}

*/
//For saving funtion
    private SharedPreference sharedPreference;
    Activity context = this;
    private Button registerButton;
    private Button signInButton;
    private Button finished2;
//    private Button saveRecordButton;
//    private Button getPersonalRecordsButton;
//    private Button getLeaderboardButton;
    private EditText emailField;
    //private EditText emailField2;
    private EditText codeField;
    private EditText nameField;
    private TextView accessCodeReadout;
    private ListView listView;

    //====================these are variables within which are stored the values to be posted to the DB
    private String email;
    private String userid;
    private String name;
    private boolean ifsaved;
//    private String units;
//    private String distance;
//    private String timeseconds;
//    private String avgspeed;
//    private String maxspeed;
    //==================================================================================================

//    private void addEmployee(){
//        final String name = emailField.getText().toString().trim();
//
//        class AddUser extends AsyncTask<Void,Void,String> {
//
//            ProgressDialog loading;
//
//            @Override
//            protected void onPreExecute() {
//                super.onPreExecute();
//                loading = ProgressDialog.show(signup.this,"Adding...","Wait...",false,false);
//            }
//
//            @Override
//            protected String doInBackground(Void... v) {
//                HashMap<String,String> params = new HashMap<String,String>();
//                params.put(Config.KEY_EMP_NAME,name);
//                RequestHandler rh = new RequestHandler();
//                String res = rh.sendPostRequest(Config.URL_ADD, params);
//                return res;
//            }
//
//            @Override
//            protected void onPostExecute(String s) {
//                super.onPostExecute(s);
//                loading.dismiss();
//                Toast.makeText(signup.this, s, Toast.LENGTH_LONG).show();
//            }
//        }
//        AddUser au = new AddUser();
//        au.execute();
//    }
    private void addUser(){

        class AddUser extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(signup.this,"Adding...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<String,String>();
                params.put(Config.KEY_USR_EMAIL,email);
                params.put(Config.KEY_USR_NAME,name);
                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(Config.URL_ADD_USER, params);
                return res;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                retrieveAccessCode();
                Toast.makeText(signup.this, s, Toast.LENGTH_LONG).show();
            }
        }
        AddUser au = new AddUser();
        au.execute();
    }

//    private void addRecord(){
//        class AddRecord extends AsyncTask<Void,Void,String> {
//
//            ProgressDialog loading;
//            @Override
//            protected void onPreExecute() {
//                super.onPreExecute();
//                loading = ProgressDialog.show(signup.this,"Adding...","Wait...",false,false);
//            }
//
//            @Override
//            protected String doInBackground(Void... v) {
//                HashMap<String,String> params = new HashMap<String,String>();
//                params.put(Config.KEY_USR_EMAIL,email);
//                params.put(Config.KEY_USR_NAME,name);
//                params.put(Config.KEY_USR_ID,userid);
//                params.put(Config.KEY_USR_UNITS,units);
//                params.put(Config.KEY_USR_DIS,distance);
//                params.put(Config.KEY_USR_TIME,timeseconds);
//                params.put(Config.KEY_USR_AVGSP,avgspeed);
//                params.put(Config.KEY_USR_MAXSP,maxspeed);
//                RequestHandler rh = new RequestHandler();
//                String res = rh.sendPostRequest(Config.URL_ADD_RECORD, params);
//                return res;
//            }
//
//            @Override
//            protected void onPostExecute(String s) {
//                super.onPostExecute(s);
//                loading.dismiss();
//                Toast.makeText(signup.this, s, Toast.LENGTH_LONG).show();
//            }
//        }
//        AddRecord ar = new AddRecord();
//        ar.execute();
//    }



    //    private void showAll(String json){
//        try {
//            JSONObject jsonObject = new JSONObject(json);
//            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);
//            JSONObject c = result.getJSONObject(0);
//            String name = c.getString(Config.TAG_NAME);
////			String desg = c.getString(Config.TAG_DESG);
////			String sal = c.getString(Config.TAG_SAL);
//            String id = c.getString(Config.TAG_ID);
//            String email = c.getString(Config.TAG_EMAIL);
//            String date = c.getString(Config.TAG_DATE);
//            String distance = c.getString(Config.TAG_DIS);
//            String units = c.getString(Config.TAG_UNITS);
//            String timeInSeconds = c.getString(Config.TAG_TIME);
//            String avgSpeed = c.getString(Config.TAG_AVGSP);
//
//            emailField.setText(email);
////            registerButton.setText(id);
////            signInButton.setText(name);
////            emailField.setText(date);
////            emailField.setText(distance);
////            emailField.setText(units);
////            emailField.setText(timeInSeconds);
////            emailField.setText(avgSpeed);
////			editTextDesg.setText(desg);
////			editTextSalary.setText(sal);
//
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//    }
    private void checkUserJSON(String json){//for registration: checking if the user exists. If not, we add as new to users table
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);
            JSONObject c = result.getJSONObject(0);
            String email = c.getString(Config.TAG_EMAIL);
            String id = c.getString(Config.TAG_ID);

            if (id == "null" && email == "null")
            {
                addUser();
            }
            else
                ProgressDialog.show(signup.this,"Failed...","User Exists...",false,true);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private void checkSignInJSON(String json){//for sign in
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);
            JSONObject c = result.getJSONObject(0);
            String email = c.getString(Config.TAG_EMAIL);
            String id = c.getString(Config.TAG_ID);
            String name = c.getString(Config.TAG_NAME);

            if (id == "null" && email == "null")
            {
                ProgressDialog.show(signup.this, "Failed...", "User Doesn't Exist...", false, true);
            }
            else
                nameField.setText(name);
            //name save--------------------------------------------------------------------------------------
            Context mContext3 = getApplicationContext();
            SharedPreferences mPrefs3 = mContext3.getSharedPreferences(NAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor3= mPrefs3.edit();
            editor3.putString(NAME_KEY, name);
            editor3.commit();

            //email save
            Context mContext4 = getApplicationContext();
            SharedPreferences mPrefs4 = mContext4.getSharedPreferences(EMAIL, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor4= mPrefs4.edit();
            editor4.putString(EMAIL_KEY, email);
            editor4.commit();

            //id save
            Context mContext5 = getApplicationContext();
            SharedPreferences mPrefs5 = mContext5.getSharedPreferences(ID, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor5= mPrefs5.edit();
            editor5.putString(ID_KEY, id);
            editor5.commit();
            ifsaved = true;

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
//    private void showUser(String json){
//        try {
//            JSONObject jsonObject = new JSONObject(json);
//            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);
//            JSONObject c = result.getJSONObject(0);
//            String email = c.getString(Config.TAG_EMAIL);
//
//            emailField.setText(email);
//
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//    }
//    private void showEmployee(String json){
//        try {
//            JSONObject jsonObject = new JSONObject(json);
//            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);
//            JSONObject c = result.getJSONObject(0);
//            String name = c.getString(Config.TAG_NAME);
//
//            emailField.setText(name);
////            registerButton.setText(id);
////            signInButton.setText(name);
////            emailField.setText(date);
////            emailField.setText(distance);
////            emailField.setText(units);
////            emailField.setText(timeInSeconds);
////            emailField.setText(avgSpeed);
////			editTextDesg.setText(desg);
////			editTextSalary.setText(sal);
//
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//    }

    private void showPersonalRecords(String json){
        JSONObject jsonObject = null;
        ArrayList<HashMap<String,String>> list = new ArrayList<HashMap<String, String>>();
        try {
            jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);

//            accessCodeReadout.setText(json);//debugging
            for(int i = 0; i<result.length(); i++){
                JSONObject jo = result.getJSONObject(i);
                String entrydate = jo.getString(Config.TAG_DATE);
                String distance = jo.getString(Config.TAG_DIS);
                String units = jo.getString(Config.TAG_UNITS);
                String time = jo.getString(Config.TAG_TIME);
                String avgspd = jo.getString(Config.TAG_AVGSP);

//                accessCodeReadout.setText(entrydate);//debugging

                HashMap<String,String> records = new HashMap<String,String>();
                records.put(Config.TAG_DATE,entrydate);
                records.put(Config.TAG_DIS,distance);
                records.put(Config.TAG_UNITS,units);
                records.put(Config.TAG_TIME,time);
                records.put(Config.TAG_AVGSP,avgspd);
                list.add(records);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ListAdapter adapter = new SimpleAdapter(
                signup.this, list, R.layout.list_item,
                new String[]{Config.TAG_DATE,Config.TAG_DIS,Config.TAG_UNITS,Config.TAG_TIME,Config.TAG_AVGSP},
                new int[]{R.id.date, R.id.distance, R.id.units, R.id.time, R.id.avgsp});

        listView.setAdapter(adapter);
    }

    private void retrieveAccessCode(){
        class GetUser extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(signup.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_USER,userid,email);
//                Log.d(TAG, "debugTest");
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);
                    JSONObject c = result.getJSONObject(0);
                    String accessCode = c.getString(Config.TAG_ID);

                    accessCodeReadout.setText(accessCode);
                    //name save--------------------------------------------------------------------------------------
                    Context mContext3 = getApplicationContext();
                    SharedPreferences mPrefs3 = mContext3.getSharedPreferences(NAME, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor3= mPrefs3.edit();
                    editor3.putString(NAME_KEY, name);
                    editor3.commit();

                    //email save
                    Context mContext4 = getApplicationContext();
                    SharedPreferences mPrefs4 = mContext4.getSharedPreferences(EMAIL, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor4= mPrefs4.edit();
                    editor4.putString(EMAIL_KEY, email);
                    editor4.commit();

                    //id save
                    Context mContext5 = getApplicationContext();
                    SharedPreferences mPrefs5 = mContext5.getSharedPreferences(ID, Context.MODE_PRIVATE);
                    SharedPreferences.Editor editor5= mPrefs5.edit();
                    editor5.putString(ID_KEY, accessCode);
                    editor5.commit();
                    ifsaved = true;

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        GetUser gu = new GetUser();
        gu.execute();
    }
    private void getUser(){
        class GetUser extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(signup.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_USER,userid,email);
//                Log.d(TAG, "debugTest");
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                checkUserJSON(s);
            }
        }
        GetUser gu = new GetUser();
        gu.execute();
    }
    private void signIn(){
        class GetUser extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(signup.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_USER,userid,email);
//                Log.d(TAG, "debugTest");
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                checkSignInJSON(s);
            }
        }
        GetUser gu = new GetUser();
        gu.execute();
    }
    private void getUserRegistration(){
        class GetUser extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(signup.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_USER,userid,email);
//                Log.d(TAG, "debugTest");
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                checkUserJSON(s);
            }
        }
        GetUser gu = new GetUser();
        gu.execute();
    }
    private void checkUser(){
        class checkUser extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(signup.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_USER,userid,email);
//                Log.d(TAG, "debugTest");
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                checkUserJSON(s);
            }
        }
        checkUser cu = new checkUser();
        cu.execute();
    }

//    private void getEmployee(){
//        class GetEmployee extends AsyncTask<Void,Void,String> {
//            ProgressDialog loading;
//            @Override
//            protected void onPreExecute() {
//                super.onPreExecute();
//                loading = ProgressDialog.show(signup.this,"Fetching...","Wait...",false,false);
//            }
//
//            @Override
//            protected String doInBackground(Void... params) {
//                RequestHandler rh = new RequestHandler();
//                String s = rh.sendGetRequestParam(Config.URL_GET_EMP,userid);
////                Log.d(TAG, "debugTest");
//                return s;
//            }
//
//            @Override
//            protected void onPostExecute(String s) {
//                super.onPostExecute(s);
//                loading.dismiss();
//                showEmployee(s);
//            }
//        }
//        GetEmployee ge = new GetEmployee();
//        ge.execute();
//    }



//    private void getPersonalRecords(){
//        class GetPersonalRecords extends AsyncTask<Void,Void,String>{
//
//            ProgressDialog loading;
//
//            @Override
//            protected void onPreExecute() {
//                super.onPreExecute();
//                loading = ProgressDialog.show(signup.this,"Fetching Data","Wait...",false,false);
//            }
//            @Override
//            protected String doInBackground(Void... params) {
//                RequestHandler rh = new RequestHandler();
//                String s = rh.sendGetRequestParam(Config.URL_GET_RECORDS, userid);
//                return s;
//            }
//            @Override
//            protected void onPostExecute(String s) {
//                super.onPostExecute(s);
//                loading.dismiss();
//                showPersonalRecords(s);
//            }
//        }
//        GetPersonalRecords gpr = new GetPersonalRecords();
//        gpr.execute();
//    }


    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.signup);

        registerButton = (Button) findViewById(R.id.regButton);
        signInButton = (Button) findViewById(R.id.signInButton);
        finished2 = (Button) findViewById(R.id.confirm3);
//        saveRecordButton = (Button) findViewById(R.id.saveRecordButton);
//        getPersonalRecordsButton = (Button) findViewById(R.id.retrieveRecordsButton);
//        getLeaderboardButton = (Button) findViewById(R.id.getLeaderboardButton);
        emailField = (EditText) findViewById(R.id.emailField);
       // emailField2 = (EditText) findViewById(R.id.emailField2);
        codeField = (EditText) findViewById(R.id.codeField);
        nameField = (EditText) findViewById(R.id.nameField);
        accessCodeReadout = (TextView) findViewById(R.id.accessCodeReadout);
//        listView = (ListView) findViewById(R.id.listView);

        //loading saved name, id, and email
        //--------------------------------------------------------------------------------------------------------------------------
        sharedPreference = new SharedPreference();

        SharedPreferences settings3;
        settings3 = context.getSharedPreferences(NAME, Context.MODE_PRIVATE);
        name = settings3.getString(NAME_KEY, null);

        SharedPreferences settings4;
        settings4 = context.getSharedPreferences(ID, Context.MODE_PRIVATE);
        userid = settings4.getString(ID_KEY, null);

        SharedPreferences settings5;
        settings5 = context.getSharedPreferences(EMAIL, Context.MODE_PRIVATE);
        email = settings5.getString(EMAIL_KEY, null);
//        saveRecordButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            //If clicked, call the finish method
//            public void onClick(View v) {
//                //Finish ends the current activity and goes back to the activity that called this one (Main in this case)
//                email = "test";//what is saved to these variables shopuld come from the same file -> Namir
//                userid = "1";
//                name = "test2";
//                units = "km";//From here on it is Shaina's part
//                distance = "100";
//                timeseconds = "50";
//                avgspeed = "4";
//                maxspeed = "5";
//                addRecord();
//            }
//        });
//
//        getPersonalRecordsButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            //If clicked, call the finish method
//            public void onClick(View v) {
//                userid = "1";
////                accessCodeReadout.setText("1");//debugging
//                getPersonalRecords();
//            }
//        });
//
//        getLeaderboardButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            //If clicked, call the finish method
//            public void onClick(View v) {
//                //Finish ends the current activity and goes back to the activity that called this one (Main in this case)
//                finish();
//            }
//        });
//
//
//
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            //If clicked, call the finish method
            public void onClick(View v) {

                userid = "%25";
                email = emailField.getText().toString().trim();
                name = nameField.getText().toString().trim();
                checkUser();
            }
        });

        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            //If clicked, call the finish method
            public void onClick(View v) {

                userid = codeField.getText().toString().trim();
                email = emailField.getText().toString().trim();
                signIn();
            }
        });

        finished2.setOnClickListener(new View.OnClickListener() {
            @Override
            //If clicked, call the finish method
            public void onClick(View v) {
                //Finish ends the current activity and goes back to the activity that called this one (Main in this case)
                if (ifsaved) {
                    finish();
                }
                else{
                    Toast.makeText(signup.this, getResources().getString(R.string.error_signin), Toast.LENGTH_LONG).show();
                }
            }
        });

    }
}
