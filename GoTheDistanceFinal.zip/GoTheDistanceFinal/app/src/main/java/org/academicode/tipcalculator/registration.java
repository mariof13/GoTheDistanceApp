package org.academicode.tipcalculator;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by salem on 12/9/2015.
 */
public class registration extends Activity {

    private Button registerButton;
    private Button signInButton;
    private Button done;
    private Button saveRecordButton;
    private Button getPersonalRecordsButton;
    private Button getCompetitorRecordButton;
    private Button getLeaderboardButton;
    private Button emailAccessCodeButton;
//    private EditText emailField;
//    private EditText codeField;
//    private EditText nameField;
    private TextView accessCodeReadout;
    private TextView compNameReadout;
    private TextView compDisReadout;
    private TextView compTimeReadout;
    private TextView compDateReadout;
    private ListView listView;

    //====================these are variables within which are stored the values to be posted to the DB
    private String email;
    private String userid;
    private String name;
    private String units;
    private String distance;
    private String timeseconds;
    private String avgspeed;
    private String maxspeed;
    private String emailAddress;
    private String emailSubject;
    private String emailMessage;
    //==================================================================================================


    private void addUser(){

        class AddUser extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(registration.this,"Adding...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<String,String>();
                params.put(Config.KEY_USR_EMAIL,email);
                params.put(Config.KEY_USR_NAME,name);
                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(Config.URL_ADD_USER, params);
                return res;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                retrieveAccessCode();
                Toast.makeText(registration.this, s, Toast.LENGTH_LONG).show();
            }
        }
        AddUser au = new AddUser();
        au.execute();
    }

    private void addRecord(){
        class AddRecord extends AsyncTask<Void,Void,String> {

            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(registration.this,"Adding...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... v) {
                HashMap<String,String> params = new HashMap<String,String>();
                params.put(Config.KEY_USR_EMAIL,email);
                params.put(Config.KEY_USR_NAME,name);
                params.put(Config.KEY_USR_ID,userid);
                params.put(Config.KEY_USR_UNITS,units);
                params.put(Config.KEY_USR_DIS,distance);
                params.put(Config.KEY_USR_TIME,timeseconds);
                params.put(Config.KEY_USR_AVGSP,avgspeed);
                params.put(Config.KEY_USR_MAXSP,maxspeed);
                RequestHandler rh = new RequestHandler();
                String res = rh.sendPostRequest(Config.URL_ADD_RECORD, params);
                return res;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(registration.this, s, Toast.LENGTH_LONG).show();
            }
        }
        AddRecord ar = new AddRecord();
        ar.execute();
    }




    private void checkUserJSON(String json){//for registration: checking if the user exists. If not, we add as new to users table
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);
            JSONObject c = result.getJSONObject(0);
            String email = c.getString(Config.TAG_EMAIL);
            String id = c.getString(Config.TAG_ID);

            if (id == "null" && email == "null")
            {
                addUser();
            }
            else
                ProgressDialog.show(registration.this,"Failed...","User Exists...",false,true);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private void checkSignInJSON(String json){//for sign in
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);
            JSONObject c = result.getJSONObject(0);
            String email = c.getString(Config.TAG_EMAIL);
            String id = c.getString(Config.TAG_ID);
            String name = c.getString(Config.TAG_NAME);

            if (id == "null" && email == "null")
            {
                ProgressDialog.show(registration.this, "Failed...", "User Doesn't Exist...", false, true);
            }
//            else
//                nameField.setText(name);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private void checkCompetitorRecordJSON(String json){//for sign in
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);
            JSONObject c = result.getJSONObject(0);
            String id = c.getString(Config.TAG_ID);
            String name = c.getString(Config.TAG_NAME);
            String distance = c.getString(Config.TAG_DIS);
            String units = c.getString(Config.TAG_UNITS);
            String time = c.getString(Config.TAG_TIME);
            String date = c.getString(Config.TAG_DATE);

            if (id == "null")
            {
                ProgressDialog.show(registration.this, "Failed...", "User Doesn't Exist...", false, true);
            }
            else {
                compNameReadout.setText(name);
                compDisReadout.setText(distance+" "+units);
                compTimeReadout.setText(time);
                compDateReadout.setText(date);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private void showUser(String json){
        try {
            JSONObject jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);
            JSONObject c = result.getJSONObject(0);
            String email = c.getString(Config.TAG_EMAIL);

//            emailField.setText(email);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    private void showPersonalRecords(String json){
        JSONObject jsonObject = null;
        ArrayList<HashMap<String,String>> list = new ArrayList<HashMap<String, String>>();
        try {
            jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);

//            accessCodeReadout.setText(json);//debugging
            for(int i = 0; i<result.length(); i++){
                JSONObject jo = result.getJSONObject(i);
                String entrydate = jo.getString(Config.TAG_DATE);
                String distance = jo.getString(Config.TAG_DIS);
                String units = jo.getString(Config.TAG_UNITS);
                String time = jo.getString(Config.TAG_TIME);
                String avgspd = jo.getString(Config.TAG_AVGSP);

//                accessCodeReadout.setText(entrydate);//debugging

                HashMap<String,String> records = new HashMap<String,String>();
                records.put(Config.TAG_DATE,entrydate);
                records.put(Config.TAG_DIS,distance);
                records.put(Config.TAG_UNITS,units);
                records.put(Config.TAG_TIME,time);
                records.put(Config.TAG_AVGSP,avgspd);
                list.add(records);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ListAdapter adapter = new SimpleAdapter(
                registration.this, list, R.layout.list_item,
                new String[]{Config.TAG_DATE,Config.TAG_DIS,Config.TAG_UNITS,Config.TAG_TIME,Config.TAG_AVGSP},
                new int[]{R.id.date, R.id.distance, R.id.units, R.id.time, R.id.avgsp});

        listView.setAdapter(adapter);
    }

    private void showLeaderboard(String json){
        JSONObject jsonObject = null;
        ArrayList<HashMap<String,String>> list = new ArrayList<HashMap<String, String>>();
        try {
            jsonObject = new JSONObject(json);
            JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);

//            accessCodeReadout.setText(json);//debugging
            for(int i = 0; i<result.length(); i++){
                JSONObject jo = result.getJSONObject(i);
                String entrydate = jo.getString(Config.TAG_DATE);
                String name = jo.getString(Config.TAG_NAME);
                String time = jo.getString(Config.TAG_TIME);
                String units = jo.getString(Config.TAG_UNITS);
//                String distance = jo.getString(Config.TAG_DIS);

//                accessCodeReadout.setText(entrydate);

                HashMap<String,String> records = new HashMap<String,String>();
                records.put(Config.TAG_DATE,entrydate);
                records.put(Config.TAG_NAME, name);
                records.put(Config.TAG_TIME,time);
                records.put(Config.TAG_UNITS,units);
                list.add(records);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        ListAdapter adapter = new SimpleAdapter(
                registration.this, list, R.layout.leaderboard_list_item,
                new String[]{Config.TAG_DATE,Config.TAG_NAME,Config.TAG_TIME,Config.TAG_UNITS},
                new int[]{R.id.date, R.id.name, R.id.time, R.id.units});

        listView.setAdapter(adapter);
    }

    private void retrieveAccessCode(){
        class GetUser extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(registration.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_USER,userid,email);
//                Log.d(TAG, "debugTest");
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(s);
                    JSONArray result = jsonObject.getJSONArray(Config.TAG_JSON_ARRAY);
                    JSONObject c = result.getJSONObject(0);
                    String accessCode = c.getString(Config.TAG_ID);

                    accessCodeReadout.setText(accessCode);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        GetUser gu = new GetUser();
        gu.execute();
    }
    private void getUser(){
        class GetUser extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(registration.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_USER,userid,email);
//                Log.d(TAG, "debugTest");
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                checkUserJSON(s);
            }
        }
        GetUser gu = new GetUser();
        gu.execute();
    }
    private void signIn(){
        class GetUser extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(registration.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_USER,userid,email);
//                Log.d(TAG, "debugTest");
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                checkSignInJSON(s);
            }
        }
        GetUser gu = new GetUser();
        gu.execute();
    }
    private void getCompetitorRecord(){
        class GetUser extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(registration.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_COMP_REC,userid);
//                Log.d(TAG, "debugTest");
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                checkCompetitorRecordJSON(s);
            }
        }
        GetUser gu = new GetUser();
        gu.execute();
    }
    private void getUserRegistration(){
        class GetUser extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(registration.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_USER, userid, email);
//                Log.d(TAG, "debugTest");
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                checkUserJSON(s);
            }
        }
        GetUser gu = new GetUser();
        gu.execute();
    }
    private void checkUser(){
        class checkUser extends AsyncTask<Void,Void,String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(registration.this,"Fetching...","Wait...",false,false);
            }

            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_USER,userid,email);
//                Log.d(TAG, "debugTest");
                return s;
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                checkUserJSON(s);
            }
        }
        checkUser cu = new checkUser();
        cu.execute();
    }





    private void getPersonalRecords(){
        class GetPersonalRecords extends AsyncTask<Void,Void,String>{

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(registration.this,"Fetching Data","Wait...",false,false);
            }
            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestParam(Config.URL_GET_RECORDS, userid);
                return s;
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                showPersonalRecords(s);
            }
        }
        GetPersonalRecords gpr = new GetPersonalRecords();
        gpr.execute();
    }

    private void getLeaderboard(){
        class GetLeaderboard extends AsyncTask<Void,Void,String>{

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(registration.this,"Fetching Data","Wait...",false,false);
            }
            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestLeaderboardParam(Config.URL_GET_LEADERBOARD, distance, units);
                return s;
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
//                accessCodeReadout.setText(s);//debugging
                showLeaderboard(s);
            }
        }
        GetLeaderboard glb = new GetLeaderboard();
        glb.execute();
    }

    private void sendAccessCodeEmail(){
        class SendAccessCodeEmail extends AsyncTask<Void,Void,String>{

            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(registration.this,"Sending Email","Wait...",false,false);
            }
            @Override
            protected String doInBackground(Void... params) {
                RequestHandler rh = new RequestHandler();
                String s = rh.sendGetRequestEmailParam(Config.URL_SEND_EMAIL,emailAddress,emailMessage);//, emailSubject
                return s;
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
//                accessCodeReadout.setText(s);//debugging
//                showLeaderboard(s);
            }
        }
        SendAccessCodeEmail sae = new SendAccessCodeEmail();
        sae.execute();
    }


    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.registration);

//        registerButton = (Button) findViewById(R.id.regButton);
//        signInButton = (Button) findViewById(R.id.signInButton);
        done = (Button) findViewById(R.id.Done);
        //saveRecordButton = (Button) findViewById(R.id.saveRecordButton);
        getPersonalRecordsButton = (Button) findViewById(R.id.retrieveRecordsButton);
        getCompetitorRecordButton = (Button) findViewById(R.id.getCompRecordButton);
        getLeaderboardButton = (Button) findViewById(R.id.getLeaderboardButton);
        emailAccessCodeButton = (Button) findViewById(R.id.emailAccessCodeButton);
//        emailField = (EditText) findViewById(R.id.emailField);
//        codeField = (EditText) findViewById(R.id.codeField);
//        nameField = (EditText) findViewById(R.id.nameField);
        accessCodeReadout = (TextView) findViewById(R.id.accessCodeReadout);
        compNameReadout = (TextView) findViewById(R.id.compNameReadout);
        compDisReadout = (TextView) findViewById(R.id.compDisReadout);
        compTimeReadout = (TextView) findViewById(R.id.compTimeReadout);
        compDateReadout = (TextView) findViewById(R.id.compDateReadout);
        listView = (ListView) findViewById(R.id.listView);


//        saveRecordButton.setOnClickListener(new OnClickListener() {
//            @Override
//            //If clicked, call the finish method
//            public void onClick(View v) {
//                //Finish ends the current activity and goes back to the activity that called this one (Main in this case)
//                email = "test";
//                userid = "1";
//                name = "test2";
//                units = "km";
//                distance = "100";
//                timeseconds = "50";
//                avgspeed = "4";
//                maxspeed = "5";
//               // addRecord();
//            }
//        });

        getPersonalRecordsButton.setOnClickListener(new OnClickListener() {
            @Override
            //If clicked, call the finish method
            public void onClick(View v) {
                userid = "1";
//                accessCodeReadout.setText("1");//debugging
                getPersonalRecords();
            }
        });

        getCompetitorRecordButton.setOnClickListener(new OnClickListener() {
            @Override
            //If clicked, call the finish method
            public void onClick(View v) {
                userid = "2"; //codeField.getText().toString().trim();
//                accessCodeReadout.setText("1");//debugging
                getCompetitorRecord();
            }
        });

        getLeaderboardButton.setOnClickListener(new OnClickListener() {
            @Override
            //If clicked, call the finish method
            public void onClick(View v) {
                //Finish ends the current activity and goes back to the activity that called this one (Main in this case)
                distance = "200";
                units = "km";
                getLeaderboard();
            }
        });

        emailAccessCodeButton.setOnClickListener(new OnClickListener() {
            @Override
            //If clicked, call the finish method
            public void onClick(View v) {
                //Finish ends the current activity and goes back to the activity that called this one (Main in this case)
                userid = "6";

                emailAddress = "salemy@gmail";//emailField.getText().toString().trim();
                emailSubject = "GoTheDistance";
                emailMessage = "Code:"+userid;

                sendAccessCodeEmail();
            }
        });


//
//        registerButton.setOnClickListener(new OnClickListener() {
//            @Override
//            //If clicked, call the finish method
//            public void onClick(View v) {
//
//                userid = "%25";
//                email = emailField.getText().toString().trim();
//                name = nameField.getText().toString().trim();
//                //checkUser();
//            }
//        });
//
//        signInButton.setOnClickListener(new OnClickListener() {
//            @Override
//            //If clicked, call the finish method
//            public void onClick(View v) {
//
//                userid = codeField.getText().toString().trim();
//                email = emailField.getText().toString().trim();
//             //   signIn();
//            }
//        });

        done.setOnClickListener(new OnClickListener() {
            @Override
            //If clicked, call the finish method
            public void onClick(View v) {
                //Finish ends the current activity and goes back to the activity that called this one (Main in this case)
                finish();
            }
        });

    }
}